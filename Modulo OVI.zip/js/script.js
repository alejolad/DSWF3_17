var yScrollPorc = 0;
var yScrollTOTAL = self.innerHeight || (document.documentElement.clientHeight+document.body.clientHeight);



onscroll=function(){ 
    var yScroll=self.pageYOffset || (document.documentElement.scrollTop+document.body.scrollTop); 
    //document.getElementById('pp').innerHTML=yScroll; 
    
    yScrollTOTAL=self.innerHeight || (document.documentElement.clientHeight+document.body.clientHeight);
    //document.getElementById('pp2').innerHTML=yScrollTOTAL; 
    
    yScrollPorc = yScroll/yScrollTOTAL
    //document.getElementById('pp3').innerHTML=yScrollPorc; 

    /*if(yScrollPorc > 2.9 && yScrollPorc < 3.1 && posXactual=="-100%"){
      //window.location = '#c2i1';
    }*/
    var uno = document.getElementById("uno");
    var dos = document.getElementById("dos");
    var tres = document.getElementById("tres");

    uno.className = "numero imagen ";
    dos.className = "numero imagen ";
    tres.className = "numero imagen ";

    if(yScrollPorc > 1.7)
      tres.className = "imagen active";
    else if(yScrollPorc > 0.7)
      dos.className = "imagen active";
    else
      uno.className = "imagen active";


    //Estancar segunda página
    if(yScrollPorc > 1)
      document.getElementById("subA").style.position = 'fixed';
    else 
      document.getElementById("subA").style.position = '';
}

function ir(pagina){
  $('html,body').stop().animate({scrollTop: yScrollTOTAL*(pagina-1)}, 800, 'easeInOutSine');
}

function irh(valor){
  var elemento = document.getElementById("horizontal");  
  TweenMax.to(elemento, 1, {left:valor});
}

function active(id){
  var uno = document.getElementById("uno");
  var dos = document.getElementById("dos");
  var tres = document.getElementById("tres");

  uno.className = "numero imagen ";
  dos.className = "numero imagen ";
  tres.className = "numero imagen ";

  var elemento = document.getElementById(id);  
  elemento.className = "imagen active";
}

/*document.querySelector("#cajadetexto").onkeyup = function(event){
alert(event.keyCode);
}*/

//window.onload = function() { document.onkeyup = detectarFlecha; }

function redimensionar() {
    

 /* var topPosicionRealTop = $("#img-top").offset();

  var topAncho = $("#img-top").innerWidth();
  var topAlto = $("#img-top").innerHeight();

  $("#top-l").css("top", topAlto+topPosicionRealTop.top);*/


}

redimensionar();


function iniciar(){
  document.onkeyup = detectarFlecha;
}

function abrirMenu(){
  TweenMax.to($("#menu"), 1, {left: "0%"});
  TweenMax.to($("#menuBase"), 0.5, {left: "0%"});
  cerrarContacto();
}

var clic = 1;

function abrirContacto(){
  if(clic==1){
    TweenMax.to($("#contacto"), 1, {right: "0%"});
    TweenMax.to($("#contactoBase"), 0.5, {right: "0%"});
    clic = clic + 1;
  } else {
    TweenMax.to($("#contacto"), 0.5, {right: "-33%"});
    TweenMax.to($("#contactoBase"), 1, {right: "-34%"});
    clic = 1;
  }
}

function cerrarMenu(){
  TweenMax.to($("#menu"), 0.5, {left: "-33%"});
  TweenMax.to($("#menuBase"), 1, {left: "-34%"});
}

function cerrarContacto(){
  TweenMax.to($("#contacto"), 0.5, {right: "-33%"});
  TweenMax.to($("#contactoBase"), 1, {right: "-34%"});
}

function mostrarVentanaM2L1(){
        var ventana = document.getElementById('contenido-profundizacion-M2L1');
        ventana.style.display = 'block';
    }
function ocultarVentanaM2L1(){
        var ventana = document.getElementById('contenido-profundizacion-M2L1');
        ventana.style.display = 'none';
    }
function mostrarVentanaM2L3(){
        var ventana = document.getElementById('contenido-profundizacion-M2L3');        
        ventana.style.display = 'block';
    }
function ocultarVentanaM2L3(){
        var ventana = document.getElementById('contenido-profundizacion-M2L3');
        ventana.style.display = 'none';
    }    
 
function mostrarVentanaM2L4(){
        var ventana = document.getElementById('contenido-profundizacion-M2L4');        
        ventana.style.display = 'block';
    }
function ocultarVentanaM2L4(){
        var ventana = document.getElementById('contenido-profundizacion-M2L4');
        ventana.style.display = 'none';
    }

function mostrarVentanaM3L5(){
        var ventana = document.getElementById('contenido-profundizacion-M3L5');        
        ventana.style.display = 'block';
    }
function ocultarVentanaM3L5(){
        var ventana = document.getElementById('contenido-profundizacion-M3L5');
        ventana.style.display = 'none';
    }    

function mostrarVentanaM5L4(){
        var ventana = document.getElementById('contenido-profundizacion-M5L4');        
        ventana.style.display = 'block';
    }
function ocultarVentanaM5L4(){
        var ventana = document.getElementById('contenido-profundizacion-M5L4');
        ventana.style.display = 'none';
    }   

function mostrarVentana1998(){
        var ventana = document.getElementById('video-1998');        
        ventana.style.display = 'block';
    }
function ocultarVentana1998(){
        var ventana = document.getElementById('video-1998');
        ventana.style.display = 'none';
    }      
function mostrarVentana2003(){
        var ventana = document.getElementById('video-2003');        
        ventana.style.display = 'block';
    }
function ocultarVentana2003(){
        var ventana = document.getElementById('video-2003');
        ventana.style.display = 'none';
    }      
function mostrarVentana2016(){
        var ventana = document.getElementById('video-2016');        
        ventana.style.display = 'block';
    }
function ocultarVentana2016(){
        var ventana = document.getElementById('video-2016');
        ventana.style.display = 'none';
    }     

function mostrarProporcionalidad() {
    var ventana = document.getElementById("proporcionalidad");
    if (ventana.style.display === "none") {
        ventana.style.display = "block";
    } else {
        ventana.style.display = "none";
    }
}

function mostrarDistincion() {
    var ventana = document.getElementById("distincion");
    if (ventana.style.display === "none") {
        ventana.style.display = "block";
    } else {
        ventana.style.display = "none";
    }
}

function mostrarLimitacion() {
    var ventana = document.getElementById("limitacion");
    if (ventana.style.display === "none") {
        ventana.style.display = "block";
    } else {
        ventana.style.display = "none";
    }
}

function mostrarProteccion() {
    var ventana = document.getElementById("proteccion");
    if (ventana.style.display === "none") {
        ventana.style.display = "block";
    } else {
        ventana.style.display = "none";
    }
}

function mostrarPrecaucion() {
    var ventana = document.getElementById("precaucion");
    if (ventana.style.display === "none") {
        ventana.style.display = "block";
    } else {
        ventana.style.display = "none";
    }
}









































































function detectarFlecha(evObject) {
 
  var teclaPulsada = evObject.keyCode;

  flecha(teclaPulsada);
}

function flecha(teclaPulsada) {

  var posXactual = "0%";

  var msg = ''; 

  elemento = document.getElementById("horizontal"); 
  maximoH = document.getElementById("maximoH").value;
       
  posXactual = elemento.style.left;

  if (teclaPulsada == 39) { 
      msg = 'Derecha'; 
      
      if(posXactual=="0%" || posXactual=="")
        TweenMax.to(elemento, 1, {left:"-100%"}); 
      else if(posXactual=="-100%" && maximoH >2)
        TweenMax.to(elemento, 1, {left:"-200%"});
      else if(posXactual=="-200%" && maximoH >3)
        TweenMax.to(elemento, 1, {left:"-300%"});
      else if(posXactual=="-300%" && maximoH >4)
        TweenMax.to(elemento, 1, {left:"-400%"});
      else if(posXactual=="-400%" && maximoH >5)
        TweenMax.to(elemento, 1, {left:"-500%"});
      else if(posXactual=="-500%" && maximoH >6)
        TweenMax.to(elemento, 1, {left:"-600%"});
      else if(posXactual=="-600%" && maximoH >7)
        TweenMax.to(elemento, 1, {left:"-700%"});
      else if(posXactual=="-700%" && maximoH >8)
        TweenMax.to(elemento, 1, {left:"-800%"});
      else if(posXactual=="-800%" && maximoH >9)
        TweenMax.to(elemento, 1, {left:"-900%"});
      else if(posXactual=="-900%" && maximoH >10)
        TweenMax.to(elemento, 1, {left:"-1000%"});
      else if(posXactual=="-1000%" && maximoH >11)
        TweenMax.to(elemento, 1, {left:"-1100%"});
      else if(posXactual=="-1100%" && maximoH >12)
        TweenMax.to(elemento, 1, {left:"-1200%"});
  }

  else if (teclaPulsada == 37) { 
      msg = 'Izquierda'; 
      if(posXactual=="-1200%")
        TweenMax.to(elemento, 1, {left:"-1100%"});
      else if(posXactual=="-1100%")
        TweenMax.to(elemento, 1, {left:"-1000%"});
      else if(posXactual=="-1000%")
        TweenMax.to(elemento, 1, {left:"-900%"});
      else if(posXactual=="-900%")
        TweenMax.to(elemento, 1, {left:"-800%"});
      else if(posXactual=="-800%")
        TweenMax.to(elemento, 1, {left:"-700%"});
      else if(posXactual=="-700%")
        TweenMax.to(elemento, 1, {left:"-600%"});
      else if(posXactual=="-600%")
        TweenMax.to(elemento, 1, {left:"-500%"});
      else if(posXactual=="-500%")
        TweenMax.to(elemento, 1, {left:"-400%"});
      else if(posXactual=="-400%")
        TweenMax.to(elemento, 1, {left:"-300%"});
      else if(posXactual=="-300%")
        TweenMax.to(elemento, 1, {left:"-200%"});
      else if(posXactual=="-200%")
        TweenMax.to(elemento, 1, {left:"-100%"});
      else if(posXactual=="-100%")
        TweenMax.to(elemento, 1, {left:"0%"});
  }

  else if (teclaPulsada == 38) { msg = 'Arriba';
      if(yScrollPorc > 5.7){
            ir(6);
      }
      else if(yScrollPorc > 4.7){
            ir(5);
      }
      else if(yScrollPorc > 3.7){
            ir(4);
      }
      else if(yScrollPorc > 2.7){
            ir(3);
      }  
      else if(yScrollPorc > 1.7){
            ir(2);
      }
      else if(yScrollPorc > 0.7){
            ir(1);
      }

  }

  else if (teclaPulsada == 40) { msg = 'Abajo';
      
      if(yScrollPorc > 4.7){
            ir(7);
      }
      else if(yScrollPorc > 3.7){
            ir(6);
      }
      else if(yScrollPorc > 2.7){
            ir(5);
      }  
      else if(yScrollPorc > 1.7){
            ir(4);
      }
      else if(yScrollPorc > 0.7){
            ir(3);
      }
      else if(yScrollPorc >= 0){
            ir(2);
      }

  }

  //if (msg) {control.innerHTML += msg + '-----------------------------<br/>';}
}


