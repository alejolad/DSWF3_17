

var pagina = 1;
var totalLecciones = 8;

function mostrarLeccion(n){
  for(var i=1; i<=totalLecciones; i++)
    document.getElementById('leccion'+i).style.display = 'none';
  document.getElementById('leccion'+n).style.display = 'block';
  pagina = n;
}

function siguiente(){
  if(pagina+1<=totalLecciones)
    mostrarLeccion(pagina+1);
}

function anterior(){
  if(pagina-1>0)
    mostrarLeccion(pagina-1);
}
